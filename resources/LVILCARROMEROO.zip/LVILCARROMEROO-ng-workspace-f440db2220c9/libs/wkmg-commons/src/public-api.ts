/*
 * Public API Surface of wkmg-commons
 */

export * from './lib/wkmg-commons.module';
