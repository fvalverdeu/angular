export const environment = {
  production: true,
  API_URL: 'https://galaxy-training.herokuapp.com'
};
